/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.bcel.generic;

/**
 * Wrapper class for 'compound' operations, virtual instructions that don't exist as byte code, but give a useful
 * meaning. For example, the (virtual) PUSH instruction takes an arbitrary argument and produces the appropriate code at
 * dump time (ICONST, LDC, BIPUSH, ...). Also you can use the SWITCH instruction as a useful template for either
 * LOOKUPSWITCH or TABLESWITCH.
 *
 * The interface provides the possibility for the user to write 'templates' or 'macros' for such reusable code patterns.
 *
 * @see PUSH
 * @see SWITCH
 */
public interface CompoundInstruction {

    InstructionList getInstructionList();
}
