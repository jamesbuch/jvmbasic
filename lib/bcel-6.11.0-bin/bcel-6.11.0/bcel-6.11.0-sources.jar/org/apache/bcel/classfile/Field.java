/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.bcel.classfile;

import java.io.DataInput;
import java.io.IOException;
import java.util.Objects;

import org.apache.bcel.Const;
import org.apache.bcel.generic.Type;
import org.apache.bcel.util.BCELComparator;

/**
 * This class represents the field info structure, i.e., the representation for a variable in the class. See JVM
 * specification for details.
 */
public final class Field extends FieldOrMethod {

    /**
     * Empty array constant.
     *
     * @since 6.6.0
     */
    public static final Field[] EMPTY_ARRAY = {};

    private static BCELComparator<Field> bcelComparator = new BCELComparator<Field>() {

        @Override
        public boolean equals(final Field a, final Field b) {
            return a == b || a != null && b != null && Objects.equals(a.getName(), b.getName()) && Objects.equals(a.getSignature(), b.getSignature());
        }

        @Override
        public int hashCode(final Field o) {
            return o != null ? Objects.hash(o.getSignature(), o.getName()) : 0;
        }
    };

    /**
     * @return Comparison strategy object.
     */
    public static BCELComparator<Field> getComparator() {
        return bcelComparator;
    }

    /**
     * @param comparator Comparison strategy object.
     */
    public static void setComparator(final BCELComparator<Field> comparator) {
        bcelComparator = comparator;
    }

    /**
     * Constructs object from file stream.
     *
     * @param file Input stream.
     */
    Field(final DataInput file, final ConstantPool constantPool) throws IOException, ClassFormatException {
        super(file, constantPool);
    }

    /**
     * Initialize from another object. Note that both objects use the same references (shallow copy). Use clone() for a
     * physical copy.
     *
     * @param c Source to copy.
     */
    public Field(final Field c) {
        super(c);
    }

    /**
     * @param accessFlags Access rights of field
     * @param nameIndex Points to field name in constant pool
     * @param signatureIndex Points to encoded signature
     * @param attributes Collection of attributes
     * @param constantPool Array of constants
     */
    public Field(final int accessFlags, final int nameIndex, final int signatureIndex, final Attribute[] attributes, final ConstantPool constantPool) {
        super(accessFlags, nameIndex, signatureIndex, attributes, constantPool);
    }

    /**
     * Called by objects that are traversing the nodes of the tree implicitly defined by the contents of a Java class.
     * I.e., the hierarchy of methods, fields, attributes, etc. spawns a tree of objects.
     *
     * @param v Visitor object
     */
    @Override
    public void accept(final Visitor v) {
        v.visitField(this);
    }

    /**
     * @return deep copy of this field
     */
    public Field copy(final ConstantPool constantPool) {
        return (Field) copy_(constantPool);
    }

    /**
     * Return value as defined by given BCELComparator strategy. By default two Field objects are said to be equal when
     * their names and signatures are equal.
     *
     * @see Object#equals(Object)
     */
    @Override
    public boolean equals(final Object obj) {
        return obj instanceof Field && bcelComparator.equals(this, (Field) obj);
    }

    /**
     * @return constant value associated with this field (may be null)
     */
    public ConstantValue getConstantValue() {
        for (final Attribute attribute : super.getAttributes()) {
            if (attribute.getTag() == Const.ATTR_CONSTANT_VALUE) {
                return (ConstantValue) attribute;
            }
        }
        return null;
    }

    /**
     * See https://docs.oracle.com/javase/specs/jvms/se8/html/jvms-4.html#jvms-4.2.2
     *
     * @return type of field
     */
    public Type getType() {
        return Type.getType(getSignature());
    }

    /**
     * Return value as defined by given BCELComparator strategy. By default return the hash code of the field's name XOR
     * signature.
     *
     * @see Object#hashCode()
     */
    @Override
    public int hashCode() {
        return bcelComparator.hashCode(this);
    }

    /**
     * Return string representation close to declaration format, for example: 'public static final short MAX = 100'.
     *
     * @return String representation of field, including the signature.
     */
    @Override
    public String toString() {
        // Get names from constant pool
        String access = Utility.accessToString(super.getAccessFlags());
        access = access.isEmpty() ? "" : access + " ";
        final String signature = Utility.signatureToString(getSignature());
        final String name = getName();
        final StringBuilder buf = new StringBuilder(64); // CHECKSTYLE IGNORE MagicNumber
        buf.append(access).append(signature).append(" ").append(name);
        final ConstantValue cv = getConstantValue();
        if (cv != null) {
            buf.append(" = ").append(cv);
        }
        for (final Attribute attribute : super.getAttributes()) {
            if (!(attribute instanceof ConstantValue)) {
                buf.append(" [").append(attribute).append("]");
            }
        }
        return buf.toString();
    }
}
